package upn.jogja.praktikum_mobile_si

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
